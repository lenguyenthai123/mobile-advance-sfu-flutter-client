part of 'app_pages.dart';

abstract class Routes {
  static const ROOT = '/root';
  static const HOME = '/home';
}
