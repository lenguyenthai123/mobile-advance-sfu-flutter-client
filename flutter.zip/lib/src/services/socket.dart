import 'dart:convert';

import 'package:get/get.dart';
import 'package:flutter_sfu_video_call/src/pages/home/widgets/remote_view_card.dart';
import 'package:flutter_sfu_video_call/src/services/socket_emit.dart';
import 'package:socket_io_client/socket_io_client.dart';




