class ApiGateway {
  static const LOGIN = 'api/auth/login';
  static const REGISTER = 'api/auth/register';
}
