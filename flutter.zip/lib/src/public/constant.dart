import 'package:get/get.dart';

const baseUrl = 'http://localhost:port/route';
var width = Get.width;
var height = Get.height;
