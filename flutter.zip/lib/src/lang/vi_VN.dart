const Map<String, String> vi_VN = {};
